# Debugging a C# Azure Bot Service bot in Visual Studio 

To learn how to debug Azure Bot Service bots, please visit https://aka.ms/bf-docs-azure-debug